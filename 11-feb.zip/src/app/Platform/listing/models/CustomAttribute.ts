export class CustomAttribute
{
    value:string;
    text:string;
    aspectName:string;
    aspectType:string;
}

export class eBayCategoryAspects
{
    aspectType:string;
    aspectName:string;
    aspectValue:string;
}