export interface ShippinServicesModel {
    presetMapId:any;
    service: any;
    location: any;
    mode:any;
    cost:any;
    eachAdditional:any;
  }