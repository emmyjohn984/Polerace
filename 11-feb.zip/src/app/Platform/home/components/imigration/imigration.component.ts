import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-imigration',
  templateUrl: './imigration.component.html',
  styleUrls: ['./imigration.component.scss']
})
export class ImigrationComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
