export class eBayAuthorizeCode {
    authCode: string = "";
}