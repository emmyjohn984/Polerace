export default class register{
    username !: string;
    email !: string;
    password !: string;
    SubscriptionId !: number;
    companyname !: String;
    phone !: String;
}
