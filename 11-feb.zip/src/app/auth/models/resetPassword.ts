export default class resetPassword {
    userid !: String;
    password !: string;
}

export interface Itest {
    GameType: string;
    count: number;
}
