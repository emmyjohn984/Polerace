export default class forgotPassword{
    ForgetPasswordEmailId ?: string;
}
