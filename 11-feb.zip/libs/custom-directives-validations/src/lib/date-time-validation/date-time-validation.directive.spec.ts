import { DateTimeValidationDirective } from './date-time-validation.directive';

describe('DateTimeValidationDirective', () => {
  it('should create an instance', () => {
    const directive = new DateTimeValidationDirective();
    expect(directive).toBeTruthy();
  });
});
