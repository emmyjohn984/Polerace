export interface ApiParams {
  Key: string;
  Value: string;
}
